package com.example.agricultureapplication.consts

object ApiConsts {
    const val webApiBaseUrl = "https://different-toy-production.up.railway.app"
}