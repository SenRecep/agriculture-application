package com.example.agricultureapplication.models.api

data class Pager(
    val skip:Number,
    val take:Number=5
)