package com.example.agricultureapplication.exceptions

import java.io.IOException


class OfflineException(message: String) : IOException(message)