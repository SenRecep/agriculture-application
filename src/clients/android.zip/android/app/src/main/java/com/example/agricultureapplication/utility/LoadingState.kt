package com.example.agricultureapplication.utility

enum class LoadingState {
    Loading,
    Loaded
}