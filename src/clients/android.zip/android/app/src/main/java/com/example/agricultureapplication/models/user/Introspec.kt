package com.example.agricultureapplication.models.user

import com.google.gson.annotations.SerializedName

data class Introspec(@SerializedName("active") var Active:Boolean);