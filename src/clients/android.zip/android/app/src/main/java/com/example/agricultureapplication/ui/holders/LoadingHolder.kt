package com.example.agricultureapplication.ui.holders

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class LoadingHolder(view:View) :RecyclerView.ViewHolder(view){
}